# PLAN - Sistema de Login Web

## Overview
Desenvolvimento de um sistema de autenticação web completo (Login/Cadastro e Área Protegida) com um backend robusto em Node.js (Express) e um frontend em Vanilla HTML/CSS/JS.

## Project Type
**WEB** && **BACKEND** (Fullstack WebApp)
- Frontend Agent: `frontend-specialist`
- Backend Agent: `backend-specialist`
- Security/Auth Agent: `security-auditor`

## Success Criteria
- 100% dos testes de endpoint passando (registro, login, logout, me).
- Token com invalidade funcional na blocklist no logoff.
- Senhas protegidas com hash (bcrypt, 10 rounds).
- Validações de segurança aplicadas (senhas complexas, email único).
- Alternância em SPA da tela de Registro/Login (sem reload).
- Nenhuma vulnerabilidade apontada no `security_scan.py`.

## Tech Stack
- **Backend:** Node.js, Express.js
- **Segurança:** express-rate-limit, jsonwebtoken (JWT), bcrypt, helmet, cors, dotenv
- **Armazenamento:** Arquivo `users.json` local
- **Frontend:** HTML5, Vanilla CSS, JS `fetch` nativo

## File Structure
```
projeto/
├── server.js                  # Entry point (servidor Express)
├── users.json                 # Banco de dados de usuários
├── .env                       # Segredos
├── middleware/
│   └── auth.js                # Proteção via JWT e verificação na blocklist
├── routes/
│   ├── auth.js                # Endpoints (login, logout, register)
│   └── user.js                # Endpoints restritos (me)
└── public/
    ├── index.html             # Interfaz SPA Login/Register/Dasboard
    ├── style.css              # Design e Layout
    └── app.js                 # Lógica do frontend
```

## Task Breakdown

### Task 1: Estrutura Base e Backend Foundations
- **Agent:** `backend-specialist`
- **Skills:** `nodejs-best-practices`
- **Priority:** P0
- **Dependencies:** Nenhuma
- **Input:** Criação de `server.js`, instalação via `npm`
- **Output:** Express rodando com dotenv, helmet e cors na base de rotas.
- **Verify:** Server start via `npm start` acessível na porta estipulada via browser.

### Task 2: Design do Banco de Usuários e Tratamentos
- **Agent:** `backend-specialist`
- **Skills:** `nodejs-best-practices`
- **Priority:** P1
- **Dependencies:** Task 1
- **Input:** Criação de `users.json`
- **Output:** Funções/helpers para ler e gravar arquivo JSON com parsing seguro.
- **Verify:** Uma conta manual (ou teste) consegue ler/escrever.

### Task 3: Lógica de Autenticação, Rate Limiting e Blocklist
- **Agent:** `security-auditor` & `backend-specialist`
- **Skills:** `api-patterns`
- **Priority:** P0
- **Dependencies:** Task 1 e Task 2
- **Input:** Criptografia bcrypt e controle JWT + Blocklist nos arquivos `routes/auth.js` e `middleware/auth.js`.
- **Output:** Endpoints funcionais (`/register`, `/login`, `/logout`, `/me`). Rate Limit aplicado ao Login.
- **Verify:** Chamadas cURL ou Postman para `/register` reagem com success, `/login` devolve JWT, logout bloqueia access tokens subsequentes ao endpoint.

### Task 4: Frontend UI (Marcação e Estilização)
- **Agent:** `frontend-specialist`
- **Skills:** `clean-code`
- **Priority:** P2
- **Dependencies:** Nenhuma (independente)
- **Input:** HTML Canvas para login/signup e protected page.
- **Output:** `public/index.html` e `public/style.css` com feedback visual de login/cadastro e animações microinterativas (sem refresh).
- **Verify:** Renderização limpa e testada nos cenários de erro/inativo/logado.

### Task 5: Frontend JS Connections
- **Agent:** `frontend-specialist`
- **Skills:** `frontend-design`
- **Priority:** P1
- **Dependencies:** Task 3 & Task 4
- **Input:** `public/app.js` enviando requisições com Fetch em modelo Bearer Token via Header.
- **Output:** UI reativa à API (sucesso, rejeição, erros "Não foi possível logar", sem divulgar o motivo por segredo). Transição para view `Protected` ao logar.
- **Verify:** E2E visual manual pelo navegador verificando armazenamento ao `localStorage` e leitura correta.

## ✅ Phase X: Verification
- [ ] Segurança: `python .agent/skills/vulnerability-scanner/scripts/security_scan.py .`
- [ ] UI/UX Audit: `python .agent/skills/frontend-design/scripts/ux_audit.py .`
- [ ] Build Test: Ligar o servidor `npm start`
- [ ] E2E Manual testing (registrando no frontend, logando, e efetuando logout invalidando tokens).
- [ ] No Hardcoded secrets.
- [ ] Clean code validation.
