const fs = require('fs').promises;
const path = require('path');
const tasksFile = path.join(__dirname, 'tasks.json');
async function test() {
    try {
        console.log("reading...");
        const data = await fs.readFile(tasksFile, 'utf8');
        console.log("Parsing...");
        const json = JSON.parse(data);
        console.log("Total entries:", json.length);
        console.log("ID 03ae8de0 exists:", json.some(t => t.id === '03ae8de0-fd4d-4ded-ab50-1a829f9d46b6'));
        console.log("UserID of the task:", json.find(t => t.id === '03ae8de0-fd4d-4ded-ab50-1a829f9d46b6').userId);
    } catch(err) {
        console.error("Error:", err);
    }
}
test();
