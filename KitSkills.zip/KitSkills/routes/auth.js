const express = require('express');
const bcrypt = require('bcrypt');
const jwt = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const { getUsers, saveUsers } = require('../utils/db');
const { authenticateToken, blockToken } = require('../middleware/auth');

const router = express.Router();

const validatePassword = (password) => {
    const regex = /^(?=.*[A-Z])(?=.*\d)(?=.*[!@#$%^&*]).{8,}$/;
    return regex.test(password);
};

const validateEmail = (email) => {
    const regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return regex.test(email);
};

// Cadastro
router.post('/register', async (req, res) => {
    try {
        const { nome, email, password } = req.body;

        if (!nome || !email || !password) {
            return res.status(400).json({ error: 'Todos os campos são obrigatórios.' });
        }

        if (!validateEmail(email)) {
            return res.status(400).json({ error: 'E-mail inválido.' });
        }

        if (!validatePassword(password)) {
            return res.status(400).json({ error: 'A senha deve ter no mínimo 8 caracteres, com pelo menos 1 maiúscula, 1 número e 1 caractere especial (!@#$%^&*).' });
        }

        const users = await getUsers();
        
        if (users.find(u => u.email === email)) {
            return res.status(400).json({ error: 'Falha ao registrar usuário.' }); // Mensagem genérica se já existir
        }

        const saltRounds = 10;
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        const newUser = {
            id: Date.now().toString(),
            nome,
            email,
            password: hashedPassword
        };

        users.push(newUser);
        await saveUsers(users);

        res.status(201).json({ message: 'Usuário cadastrado com sucesso.' });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro no servidor.' });
    }
});

// Login
router.post('/login', async (req, res) => {
    try {
        const { email, password } = req.body;

        if (!email || !password) {
            return res.status(400).json({ error: 'E-mail e senha são obrigatórios.' });
        }

        const users = await getUsers();
        const user = users.find(u => u.email === email);

        if (!user) {
            return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
        }

        const match = await bcrypt.compare(password, user.password);
        if (!match) {
            return res.status(401).json({ error: 'E-mail ou senha incorretos.' });
        }

        const token = jwt.sign(
            { id: user.id, email: user.email, nome: user.nome },
            process.env.JWT_SECRET,
            { expiresIn: '1h' }
        );

        res.json({ token, user: { id: user.id, nome: user.nome, email: user.email } });
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Erro no servidor.' });
    }
});

// Logout
router.post('/logout', authenticateToken, (req, res) => {
    blockToken(req.token);
    res.json({ message: 'Logout realizado com sucesso. Token invalidado.' });
});

module.exports = router;
