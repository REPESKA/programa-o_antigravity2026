const express = require('express');
const fs = require('fs').promises;
const path = require('path');
const crypto = require('crypto');
const { authenticateToken } = require('../middleware/auth');

const router = express.Router();
const tasksFile = path.join(__dirname, '..', 'tasks.json');

// Simple Mutex for JSON operations
let isLocked = false;
async function acquireLock() {
    while (isLocked) {
        await new Promise(resolve => setTimeout(resolve, 10)); // wait 10ms
    }
    isLocked = true;
}
function releaseLock() {
    isLocked = false;
}

// Helper to read tasks
async function readTasks() {
    await acquireLock();
    try {
        const data = await fs.readFile(tasksFile, 'utf8');
        if (!data || data.trim() === '') return [];
        return JSON.parse(data);
    } catch (err) {
        if (err.code === 'ENOENT') return [];
        console.error('JSON Parse Error:', err);
        throw err; // Fail explicitly instead of returning [] and causing 404s
    } finally {
        releaseLock();
    }
}

// Helper to write tasks
async function writeTasks(tasks) {
    await acquireLock();
    try {
        await fs.writeFile(tasksFile, JSON.stringify(tasks, null, 2), 'utf8');
    } finally {
        releaseLock();
    }
}

// GET /api/tasks: Returns only the tasks of the authenticated user
router.get('/', authenticateToken, async (req, res) => {
    try {
        const tasks = await readTasks();
        const userTasks = tasks.filter(t => t.userId === req.user.id);
        res.json(userTasks);
    } catch (err) {
        console.error('Error reading tasks:', err);
        res.status(500).json({ error: 'Erro ao buscar tarefas.' });
    }
});

// POST /api/tasks: Creates a new task
router.post('/', authenticateToken, async (req, res) => {
    try {
        const { title, description, priority, startDate, deadline } = req.body;
        
        if (!title) {
            return res.status(400).json({ error: 'Título é obrigatório.' });
        }

        const validPriorities = ['low', 'medium', 'high'];
        const taskPriority = validPriorities.includes(priority) ? priority : 'low';

        if (startDate && deadline && new Date(deadline) < new Date(startDate)) {
            return res.status(400).json({ error: 'Data limite (deadline) não pode ser menor que a data de início (startDate).' });
        }

        const newTask = {
            id: crypto.randomUUID(),
            userId: req.user.id,
            title,
            description: description || '',
            status: 'todo',
            priority: taskPriority,
            createdAt: new Date().toISOString(),
            startDate: startDate || new Date().toISOString(),
            deadline: deadline || null,
            completedAt: null
        };

        const tasks = await readTasks();
        tasks.push(newTask);
        await writeTasks(tasks);

        res.status(201).json(newTask);
    } catch (err) {
        console.error('Error creating task:', err);
        res.status(500).json({ error: 'Erro ao criar tarefa.' });
    }
});

// PATCH /api/tasks/:id: Updates an existing task
router.patch('/:id', authenticateToken, async (req, res) => {
    try {
        const { status, priority, title, description, deadline } = req.body;
        const taskId = req.params.id;

        const tasks = await readTasks();
        const taskIndex = tasks.findIndex(t => t.id === taskId);

        if (taskIndex === -1) {
            return res.status(404).json({ error: 'Tarefa não encontrada.' });
        }

        if (tasks[taskIndex].userId !== req.user.id) {
            return res.status(403).json({ error: 'Acesso negado.' });
        }

        const validStatuses = ['todo', 'doing', 'done'];
        const validPriorities = ['low', 'medium', 'high'];

        let task = tasks[taskIndex];

        if (title) task.title = title;
        if (description !== undefined) task.description = description;
        if (priority && validPriorities.includes(priority)) task.priority = priority;
        if (deadline) task.deadline = deadline;

        if (status && validStatuses.includes(status)) {
            task.status = status;
            if (status === 'done' && !task.completedAt) {
                task.completedAt = new Date().toISOString();
            } else if (status !== 'done') {
                task.completedAt = null;
            }
        }

        tasks[taskIndex] = task;
        await writeTasks(tasks);

        res.json(task);
    } catch (err) {
        console.error('Error updating task:', err);
        res.status(500).json({ error: 'Erro ao atualizar tarefa.' });
    }
});

// DELETE /api/tasks/:id: Deletes a task
router.delete('/:id', authenticateToken, async (req, res) => {
    try {
        const taskId = req.params.id;
        const tasks = await readTasks();
        const taskIndex = tasks.findIndex(t => t.id === taskId);

        if (taskIndex === -1) {
            return res.status(404).json({ error: 'Tarefa não encontrada.' });
        }

        if (tasks[taskIndex].userId !== req.user.id) {
            return res.status(403).json({ error: 'Acesso negado.' });
        }

        tasks.splice(taskIndex, 1);
        await writeTasks(tasks);

        res.json({ message: 'Tarefa deletada com sucesso.' });
    } catch (err) {
        console.error('Error deleting task:', err);
        res.status(500).json({ error: 'Erro ao deletar tarefa.' });
    }
});

module.exports = router;
