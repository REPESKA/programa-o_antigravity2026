require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const path = require('path');

const app = express();

// Security Middlewares
app.use(helmet());
app.use(cors());

// Limitador de tentativas de login (Proteção contra brute force)
const loginLimiter = rateLimit({
    windowMs: 15 * 60 * 1000, 
    max: 5, 
    message: { error: 'Muitas tentativas. Tente novamente mais tarde.' }
});

// Body parsers
app.use(express.json());

// Arquivos Estáticos (Front-end)
app.use(express.static(path.join(__dirname, 'public')));

// Rotas da API
app.use('/api/auth/login', loginLimiter);
app.use('/api/auth', require('./routes/auth'));
app.use('/api/user', require('./routes/user'));
app.use('/api/tasks', require('./routes/tasks'));

// Tratamento de falhas
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Erro interno do servidor.' });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`🚀 Servidor rodando em http://localhost:${PORT}`);
});
