document.addEventListener('DOMContentLoaded', () => {
    // DOM Elements
    const authSection = document.getElementById('auth-section');
    const dashboardSection = document.getElementById('dashboard-section');
    const loginWrapper = document.getElementById('login-wrapper');
    const registerWrapper = document.getElementById('register-wrapper');
    const alertBox = document.getElementById('alert-box');
    
    // Forms & Inputs
    const loginForm = document.getElementById('login-form');
    const registerForm = document.getElementById('register-form');
    const btnLogout = document.getElementById('btn-logout');
    
    // Switch links
    const goToRegister = document.getElementById('go-to-register');
    const goToLogin = document.getElementById('go-to-login');
    
    // User Display
    const userNameDisplay = document.getElementById('user-name-display');
    const userEmailDisplay = document.getElementById('user-email-display');
    const userIdDisplay = document.getElementById('user-id-display');

    // API Base URL
    const API_BASE = '/api';

    // Verify initial state
    checkAuthStatus();

    // Toggle forms
    goToRegister.addEventListener('click', (e) => {
        e.preventDefault();
        hideAlert();
        loginWrapper.classList.add('hidden');
        registerWrapper.classList.remove('hidden');
        registerWrapper.classList.add('slide-in');
    });

    goToLogin.addEventListener('click', (e) => {
        e.preventDefault();
        hideAlert();
        registerWrapper.classList.add('hidden');
        loginWrapper.classList.remove('hidden');
        loginWrapper.classList.add('slide-in');
    });

    // Login Handler
    loginForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const email = document.getElementById('login-email').value;
        const password = document.getElementById('login-password').value;
        const btn = document.getElementById('btn-login');

        setLoading(btn, true, 'Entrar');

        try {
            const res = await fetch(`${API_BASE}/auth/login`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ email, password })
            });

            const data = await res.json();

            if (res.ok) {
                localStorage.setItem('auth_token', data.token);
                showAlert('Login realizado com sucesso!', 'success');
                setTimeout(() => {
                    loginForm.reset();
                    showDashboard(data.user);
                }, 1000);
            } else {
                showAlert(data.error || 'Erro ao realizar login', 'error');
            }
        } catch (error) {
            showAlert('Falha na comunicação com o servidor', 'error');
        } finally {
            setLoading(btn, false, 'Entrar');
        }
    });

    // Register Handler
    registerForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const nome = document.getElementById('reg-name').value;
        const email = document.getElementById('reg-email').value;
        const password = document.getElementById('reg-password').value;
        const btn = document.getElementById('btn-register');

        setLoading(btn, true, 'Registrar');

        try {
            const res = await fetch(`${API_BASE}/auth/register`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ nome, email, password })
            });

            const data = await res.json();

            if (res.ok) {
                showAlert('Conta criada com sucesso! Faça login.', 'success');
                setTimeout(() => {
                    registerForm.reset();
                    goToLogin.click();
                }, 1500);
            } else {
                showAlert(data.error || 'Erro ao criar conta', 'error');
            }
        } catch (error) {
            showAlert('Falha na comunicação com o servidor', 'error');
        } finally {
            setLoading(btn, false, 'Registrar');
        }
    });

    // Logout Handler
    btnLogout.addEventListener('click', async () => {
        const token = localStorage.getItem('auth_token');
        const btn = btnLogout;
        setLoading(btn, true, 'Sair da Conta');

        try {
            if (token) {
                await fetch(`${API_BASE}/auth/logout`, {
                    method: 'POST',
                    headers: { 'Authorization': `Bearer ${token}` }
                });
            }
        } catch (error) {
            console.error('Logout error:', error);
        } finally {
            setLoading(btn, false, 'Sair da Conta');
            localStorage.removeItem('auth_token');
            showAuth();
            showAlert('Você saiu com sucesso.', 'success');
        }
    });

    // Check auth status
    async function checkAuthStatus() {
        const token = localStorage.getItem('auth_token');
        if (!token) {
            showAuth();
            return;
        }

        try {
            const res = await fetch(`${API_BASE}/user/me`, {
                method: 'GET',
                headers: { 'Authorization': `Bearer ${token}` }
            });

            if (res.ok) {
                const data = await res.json();
                showDashboard(data.user);
            } else {
                // Token invalid or expired
                localStorage.removeItem('auth_token');
                showAuth();
            }
        } catch (error) {
            console.error('Session check error', error);
            showAuth();
        }
    }

    // UI Helpers
    function showAuth() {
        dashboardSection.classList.add('hidden');
        authSection.classList.remove('hidden');
        authSection.classList.add('slide-in');
    }

    function showDashboard(user) {
        hideAlert();
        authSection.classList.add('hidden');
        dashboardSection.classList.remove('hidden');
        dashboardSection.classList.add('slide-in');
        
        userNameDisplay.textContent = user.nome;
        userEmailDisplay.textContent = user.email;
        userIdDisplay.textContent = user.id;
    }

    function showAlert(message, type) {
        alertBox.textContent = message;
        alertBox.className = `alert-box alert-${type}`;
        alertBox.classList.remove('hidden');
    }

    function hideAlert() {
        alertBox.classList.add('hidden');
        alertBox.textContent = '';
    }

    function setLoading(btn, isLoading, originalText) {
        if (isLoading) {
            btn.textContent = 'Aguarde...';
            btn.disabled = true;
        } else {
            btn.textContent = originalText;
            btn.disabled = false;
        }
    }
});
