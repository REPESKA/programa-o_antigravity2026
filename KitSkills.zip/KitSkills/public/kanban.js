document.addEventListener('DOMContentLoaded', () => {
    const API_BASE = '/api';
    
    // Auth Check
    const token = localStorage.getItem('auth_token');
    if (!token) {
        window.location.href = 'index.html';
        return;
    }

    let tasks = [];

    // Elements
    const colTodo = document.querySelector('#col-todo .tasks-container');
    const colDoing = document.querySelector('#col-doing .tasks-container');
    const colDone = document.querySelector('#col-done .tasks-container');
    
    const countTodo = document.getElementById('count-todo');
    const countDoing = document.getElementById('count-doing');
    const countDone = document.getElementById('count-done');

    // Modals
    const modalTask = document.getElementById('modal-task');
    const modalTitle = document.querySelector('#modal-task .modal-header h2');
    const btnNewTask = document.getElementById('btn-new-task');
    const btnCloseModal = document.getElementById('close-task-modal');
    const btnCancelTask = document.getElementById('btn-cancel-task');
    const taskForm = document.getElementById('task-form');
    let editingTaskId = null;

    // Logout
    document.getElementById('btn-logout').addEventListener('click', () => {
        localStorage.removeItem('auth_token');
        tasks = [];
        window.location.href = 'index.html';
    });

    // Initialize
    fetchTasks();

    // API Handling
    async function fetchTasks() {
        try {
            const res = await fetch(`${API_BASE}/tasks`, {
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (res.status === 401 || res.status === 403) {
                localStorage.removeItem('auth_token');
                window.location.href = 'index.html';
                return;
            }
            if (!res.ok) throw new Error('Falha ao buscar tarefas');
            
            tasks = await res.json();
            renderBoard();
        } catch (error) {
            console.error(error);
            alert('Erro ao carregar o Kanban.');
        }
    }

    async function createTask(taskData) {
        try {
            const res = await fetch(`${API_BASE}/tasks`, {
                method: 'POST',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json' 
                },
                body: JSON.stringify(taskData)
            });
            if (!res.ok) {
                const data = await res.json();
                throw new Error(data.error || 'Erro ao criar');
            }
            const newTask = await res.json();
            tasks.push(newTask);
            
            // if modal initial status was different from todo, we need to update it
            if (taskData.status && taskData.status !== 'todo') {
                await updateTaskStatus(newTask.id, taskData.status);
            } else {
                renderBoard();
            }
            toggleModal(false);
            taskForm.reset();
        } catch (error) {
            alert(error.message);
        }
    }

    async function updateTaskStatus(id, newStatus) {
        // Optimistic UI update partially
        const task = tasks.find(t => t.id === id);
        if (!task) return;
        
        try {
            const res = await fetch(`${API_BASE}/tasks/${id}`, {
                method: 'PATCH',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json' 
                },
                body: JSON.stringify({ status: newStatus })
            });

            if (res.status === 401 || res.status === 403) {
                alert('Sessão expirada. Faça login novamente.');
                localStorage.removeItem('auth_token');
                window.location.href = 'index.html';
                return;
            }
            
            if (!res.ok) throw new Error('Erro ao atualizar status');
            
            const updatedTask = await res.json();
            const idx = tasks.findIndex(t => t.id === id);
            if (idx !== -1) tasks[idx] = updatedTask;
            renderBoard();
            
            // if we are editing via modal, close it
            if (editingTaskId === id) {
                toggleModal(false);
                editingTaskId = null;
            }
        } catch (error) {
            alert(error.message);
            renderBoard(); // reset UI
        }
    }

    async function deleteTask(id) {
        if (!confirm('Deseja realmente excluir esta tarefa?')) return;
        
        try {
            const res = await fetch(`${API_BASE}/tasks/${id}`, {
                method: 'DELETE',
                headers: { 'Authorization': `Bearer ${token}` }
            });
            if (!res.ok) throw new Error('Erro ao excluir');
            
            tasks = tasks.filter(t => t.id !== id);
            renderBoard();
        } catch (error) {
            alert(error.message);
        }
    }

    // Modal Events
    btnNewTask.addEventListener('click', () => {
        editingTaskId = null;
        modalTitle.textContent = 'Nova Tarefa';
        toggleModal(true);
    });
    btnCloseModal.addEventListener('click', () => toggleModal(false));
    btnCancelTask.addEventListener('click', () => toggleModal(false));

    function openEditModal(task) {
        editingTaskId = task.id;
        modalTitle.textContent = 'Editar Tarefa';
        
        document.getElementById('task-title').value = task.title;
        document.getElementById('task-desc').value = task.description || '';
        document.getElementById('task-priority').value = task.priority;
        document.getElementById('task-status').value = task.status;
        
        if (task.startDate) {
            document.getElementById('task-start').value = task.startDate.split('T')[0];
        }
        if (task.deadline) {
            document.getElementById('task-deadline').value = task.deadline.split('T')[0];
        }
        
        toggleModal(true);
    }

    function toggleModal(show) {
        if (show) {
            modalTask.classList.remove('hidden');
        } else {
            modalTask.classList.add('hidden');
            taskForm.reset();
        }
    }

    taskForm.addEventListener('submit', (e) => {
        e.preventDefault();
        const start = document.getElementById('task-start').value;
        const deadline = document.getElementById('task-deadline').value;

        if (start && deadline && new Date(deadline) < new Date(start)) {
            alert('A data de prazo não pode ser menor que a de início.');
            return;
        }

        const data = {
            title: document.getElementById('task-title').value,
            description: document.getElementById('task-desc').value,
            priority: document.getElementById('task-priority').value,
            status: document.getElementById('task-status').value, // Used strictly for immediate column mapping
            startDate: start || undefined,
            deadline: deadline || undefined,
        };
        
        if (editingTaskId) {
            updateTask(editingTaskId, data);
        } else {
            createTask(data);
        }
    });
    
    async function updateTask(id, data) {
         try {
            const res = await fetch(`${API_BASE}/tasks/${id}`, {
                method: 'PATCH',
                headers: { 
                    'Authorization': `Bearer ${token}`,
                    'Content-Type': 'application/json' 
                },
                body: JSON.stringify(data)
            });
            if (!res.ok) throw new Error('Erro ao editar tarefa');
            
            const updatedTask = await res.json();
            const idx = tasks.findIndex(t => t.id === id);
            if (idx !== -1) tasks[idx] = updatedTask;
            
            renderBoard();
            toggleModal(false);
            editingTaskId = null;
        } catch (error) {
            alert(error.message);
        }
    }

    // Rendering Logic
    function renderBoard() {
        colTodo.innerHTML = '';
        colDoing.innerHTML = '';
        colDone.innerHTML = '';

        const filterSort = (status) => tasks
            .filter(t => t.status === status)
            .sort((a, b) => {
                const p = { high: 3, medium: 2, low: 1 };
                return p[b.priority] - p[a.priority];
            });

        const listTodo = filterSort('todo');
        const listDoing = filterSort('doing');
        const listDone = filterSort('done');

        countTodo.textContent = listTodo.length;
        countDoing.textContent = listDoing.length;
        countDone.textContent = listDone.length;

        listTodo.forEach(t => colTodo.appendChild(createCardHTML(t)));
        listDoing.forEach(t => colDoing.appendChild(createCardHTML(t)));
        listDone.forEach(t => colDone.appendChild(createCardHTML(t)));

        updateDashboardMetrics();
        setupDragAndDrop();
    }

    function createCardHTML(task) {
        const card = document.createElement('div');
        card.className = 'task-card';
        card.draggable = true;
        card.dataset.id = task.id;

        const isOverdue = task.deadline && new Date(task.deadline) < new Date() && task.status !== 'done';
        if (isOverdue) card.classList.add('overdue');

        const priorityMap = {
            'high': 'Alta',
            'medium': 'Média',
            'low': 'Baixa'
        };

        const formatDate = (isoStr) => isoStr ? new Date(isoStr).toLocaleDateString() : '';

        card.innerHTML = `
            <div class="card-header">
                <div class="card-title">${task.title}</div>
                <div class="priority-badge priority-${task.priority}">${priorityMap[task.priority]}</div>
            </div>
            ${task.description ? `<div class="task-desc">${task.description}</div>` : ''}
            <div class="card-meta">
                ${task.startDate ? `<div class="meta-item">▶️ ${formatDate(task.startDate)}</div>` : ''}
                ${task.deadline ? `<div class="meta-item">⏳ ${formatDate(task.deadline)}</div>` : ''}
                ${task.completedAt ? `<div class="meta-item">✅ ${formatDate(task.completedAt)}</div>` : ''}
            </div>
            <div class="card-actions">
                <div class="mark-done-wrapper">
                    ${task.status !== 'done' ? `<input type="checkbox" class="check-done" data-id="${task.id}"> <label>Concluir</label>` : `<span>Feito</span>`}
                </div>
                <div class="right-actions">
                    <button class="action-btn edit-btn" data-id="${task.id}">Editar</button>
                    <button class="action-btn del-btn" data-id="${task.id}">Excluir</button>
                </div>
            </div>
        `;

        // Bind inner actions
        const dBtn = card.querySelector('.del-btn');
        const eBtn = card.querySelector('.edit-btn');
        const cBtn = card.querySelector('.check-done');

        if (dBtn) dBtn.addEventListener('click', () => deleteTask(task.id));
        if (eBtn) eBtn.addEventListener('click', () => openEditModal(task));
        if (cBtn) {
            cBtn.addEventListener('change', (e) => {
                if(e.target.checked) updateTaskStatus(task.id, 'done');
            });
        }

        return card;
    }

    // Dashboard Metrics
    function updateDashboardMetrics() {
        const total = tasks.length;
        const done = tasks.filter(t => t.status === 'done').length;
        const todo = tasks.filter(t => t.status === 'todo').length;
        const doing = tasks.filter(t => t.status === 'doing').length;
        const overdue = tasks.filter(t => t.deadline && new Date(t.deadline) < new Date() && t.status !== 'done').length;
        
        document.getElementById('metric-total').textContent = total;
        document.getElementById('metric-todo').textContent = todo;
        document.getElementById('metric-doing').textContent = doing;
        document.getElementById('metric-done').textContent = done;
        document.getElementById('metric-overdue').textContent = overdue;
        
        const rate = total > 0 ? Math.round((done / total) * 100) : 0;
        document.getElementById('metric-rate').textContent = `${rate}%`;
    }

    // Drag and Drop implementation
    function setupDragAndDrop() {
        const cards = document.querySelectorAll('.task-card');
        const columns = document.querySelectorAll('.kanban-column');

        cards.forEach(card => {
            card.addEventListener('dragstart', (e) => {
                e.dataTransfer.setData('text/plain', card.dataset.id);
                setTimeout(() => card.classList.add('dragging'), 0);
            });

            card.addEventListener('dragend', () => {
                card.classList.remove('dragging');
            });
        });

        columns.forEach(col => {
            col.addEventListener('dragover', (e) => {
                e.preventDefault();
                col.classList.add('drag-over');
            });

            col.addEventListener('dragleave', () => {
                col.classList.remove('drag-over');
            });

            col.addEventListener('drop', (e) => {
                e.preventDefault();
                col.classList.remove('drag-over');
                
                const id = e.dataTransfer.getData('text/plain');
                const newStatus = col.dataset.status;
                const task = tasks.find(t => t.id === id);
                
                if (task && task.status !== newStatus) {
                    updateTaskStatus(id, newStatus);
                }
            });
        });
    }
});
