const jwt = require('jsonwebtoken');

// Simple in-memory blocklist (for invalidating tokens on logout)
const tokenBlocklist = new Set();

const authenticateToken = (req, res, next) => {
    const authHeader = req.headers['authorization'];
    const token = authHeader && authHeader.split(' ')[1];

    if (!token) {
        return res.status(401).json({ error: 'Acesso negado. Token não fornecido.' });
    }

    if (tokenBlocklist.has(token)) {
        return res.status(401).json({ error: 'Token inválido (sessão encerrada).' });
    }

    jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
        if (err) {
            return res.status(403).json({ error: 'Token inválido ou expirado.' });
        }
        req.user = user;
        req.token = token; // Adiciona o token para o endpoint de logout
        next();
    });
};

const blockToken = (token) => {
    tokenBlocklist.add(token);
    // Para resolver o vazamento de memória com o tempo, tokens expirados
    // seriam removidos futuramente via job, mas Set() serve para a MVP simple.
};

module.exports = { authenticateToken, blockToken };
