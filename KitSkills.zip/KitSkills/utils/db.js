const fs = require('fs/promises');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'users.json');

async function getUsers() {
    try {
        const data = await fs.readFile(DB_PATH, 'utf8');
        return JSON.parse(data);
    } catch (err) {
        if (err.code === 'ENOENT') {
            await saveUsers([]);
            return [];
        }
        throw err;
    }
}

async function saveUsers(users) {
    await fs.writeFile(DB_PATH, JSON.stringify(users, null, 2), 'utf8');
}

module.exports = { getUsers, saveUsers };
