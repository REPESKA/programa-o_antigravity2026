const notifyBtn = document.getElementById('notifyBtn');
const container = document.getElementById('notification-container');

const messages = [
    { title: 'Nova Mensagem', text: 'Você recebeu uma nova mensagem de Antigravity.' },
    { title: 'Sistema Atualizado', text: 'Os drivers de design foram carregados com sucesso.' },
    { title: 'Sucesso!', text: 'A operação foi concluída com um visual premium.' },
    { title: 'Alerta de Estilo', text: 'Sua interface está ficando incrível hoje.' },
    { title: 'Notificação', text: 'Isso é uma demonstração de animação fluida.' }
];

function createNotification() {
    // Escolhe uma mensagem aleatória
    const randomMsg = messages[Math.floor(Math.random() * messages.length)];
    
    // Cria o elemento da notificação
    const notification = document.createElement('div');
    notification.classList.add('notification');
    
    notification.innerHTML = `
        <div class="notification-content">
            <h4>${randomMsg.title}</h4>
            <p>${randomMsg.text}</p>
        </div>
        <div class="notification-progress"></div>
    `;
    
    // Adiciona ao container
    container.appendChild(notification);
    
    // Remove após 4 segundos (tempo da animação da barra de progresso)
    setTimeout(() => {
        notification.classList.add('hiding');
        notification.addEventListener('animationend', () => {
            notification.remove();
        });
    }, 4000);
}

notifyBtn.addEventListener('click', () => {
    createNotification();
});

// Mensagem de boas-vindas no console
console.log('%c Sistema de Notificação Premium Ativado ', 'background: #7c3aed; color: #fff; padding: 5px; border-radius: 5px;');
